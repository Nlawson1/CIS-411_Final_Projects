﻿using System;
using Microsoft.EntityFrameworkCore;

namespace Faqs.Models
{
    public class FaqsContext : DbContext
    {
        public FaqsContext(DbContextOptions<FaqsContext> options)
            : base(options) { }

        public DbSet<FAQ> Faqs { get; set; }
        public DbSet<Topic> Topics { get; set; }
        public DbSet<Category> Categories { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Topic>().HasData(
                new Topic { TopicId = "mh", Name = "Monster-Hunter" },
                new Topic { TopicId = "bf", Name = "Battlefield" },
                new Topic { TopicId = "er", Name = "Elden Ring" }
            );

            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = "gen", Name = "General" },
                new Category { CategoryId = "his", Name = "History" }
            );

            modelBuilder.Entity<FAQ>().HasData(
                new FAQ
                {
                    Id = 1,
                    Question = "What is Monster-Hunter?",
                    Answer = "Monster Hunter is a Japanese media franchise centered around a series of fantasy-themed action role-playing video games.",
                    TopicId = "mh",
                    CategoryId = "gen"
                },
                new FAQ
                {
                    Id = 2,
                    Question = "What is Battlefield?",
                    Answer = "Battlefield is a series of first-person shooter video games developed by Swedish company EA DICE and is published by American company Electronic Arts.",
                    TopicId = "bf",
                    CategoryId = "gen"
                },
                new FAQ
                {
                    Id = 3,
                    Question = "What is the Elden Ring?",
                    Answer = "Elden Ring is an action role-playing game developed by FromSoftware and published by Bandai Namco Entertainment.",
                    TopicId = "er",
                    CategoryId = "gen"
                },
                new FAQ
                {
                    Id = 4,
                    Question = "When was Monster-Hunter initally released?",
                    Answer = "The initial release date for Monster-Hunter was March 11th, 2004.",
                    TopicId = "mh",
                    CategoryId = "his"
                },
                new FAQ
                {
                    Id = 5,
                    Question = "When was Battlefield initally released?",
                    Answer = "Battlefield was initally released on September 10th, 2002.",
                    TopicId = "bf",
                    CategoryId = "his"
                },
                new FAQ
                {
                    Id = 6,
                    Question = "When was Elden Ring initally released?",
                    Answer = "Elden Ring was initally released on February 25th, 2022.",
                    TopicId = "er",
                    CategoryId = "his"
                }
                );
        }
    }
}

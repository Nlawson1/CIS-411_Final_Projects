﻿namespace Faqs.Models
{
    public class Topic
    {
        public string TopicId { get; set; } 
        public string Name { get; set; }
    }
}

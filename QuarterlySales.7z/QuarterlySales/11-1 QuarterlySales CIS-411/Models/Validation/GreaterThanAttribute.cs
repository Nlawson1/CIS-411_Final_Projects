﻿using System;
using System.ComponentModel.DataAnnotations;


namespace _11_1_QuarterlySales_CIS_411.Models
{
    public class GreaterThanAttribute : ValidationAttribute
    {
        private object compareValue;
        public GreaterThanAttribute(object val = null)
        {
            compareValue = val;
        }
        public string FieldName { get; set; }

        protected override ValidationResult IsValid(object value, ValidationContext ctx)
        {
            if (!string.IsNullOrEmpty(FieldName))
            {
                var propertyInfo = ctx.ObjectType.GetProperty(FieldName);
                compareValue = propertyInfo.GetValue(ctx.ObjectInstance, null);
            }
            if (value is int)
            {
                int intToCheck = (int)value;
                int intToCompare = (int)compareValue;

                if (intToCheck > intToCompare)
                {
                    return ValidationResult.Success;
                }
            }
            else if (value is double)
            {
                double doubleToCheck = (double)value;
                double doubleToCompare = (double)compareValue;

                if (doubleToCheck > doubleToCompare)
                {
                    return ValidationResult.Success;
                }
            }
            else if (value is DateTime)
            {
                DateTime dateTimeToCheck = (DateTime)value;
                DateTime dateTimeToCompare = new DateTime();

                if (compareValue is string)
                {
                    DateTime.TryParse(compareValue.ToString(), out dateTimeToCompare);
                }
                else
                {
                    dateTimeToCompare = (DateTime)compareValue;
                }
                if (dateTimeToCheck > dateTimeToCompare)
                {
                    return ValidationResult.Success;
                }
            }
            else
            {
                return ValidationResult.Success;
            }
            string msg = base.ErrorMessage ??
                $"{ctx.DisplayName} must be greater than {compareValue.ToString()}.";
            return new ValidationResult(msg);
        }
    }
}

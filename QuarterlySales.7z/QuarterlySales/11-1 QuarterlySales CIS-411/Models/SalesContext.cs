﻿using System;
using Microsoft.EntityFrameworkCore;

namespace _11_1_QuarterlySales_CIS_411.Models
{
    public class SalesContext : DbContext
    {
        public SalesContext(DbContextOptions<SalesContext> options)
            : base(options) { }

        public DbSet<Sales> Sales { get; set; }

        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().HasData(
                new Employee
                {
                    EmployeeId = 1,
                    Firstname = "Bob",
                    Lastname = "Johnson",
                    DOB = new DateTime(1985, 12, 6),
                    DateOfHire = new DateTime(2000, 1, 1),
                    ManagerId = 0
                },
                new Employee
                {
                    EmployeeId = 2,
                    Firstname = "Stewert",
                    Lastname = "Little",
                    DOB = new DateTime(1968, 11, 3),
                    DateOfHire = new DateTime(2001, 11, 4),
                    ManagerId = 1
                },
                new Employee
                {
                    EmployeeId = 3,
                    Firstname = "Kat",
                    Lastname = "Stevens",
                    DOB = new DateTime(1984, 2, 16),
                    DateOfHire = new DateTime(2004, 2, 17),
                    ManagerId = 2
                }
                );
            modelBuilder.Entity<Sales>().HasData(
                new Sales
                {
                    Quarter = 1,
                    Year = 2000,
                    Amount = 26697,
                    EmployeeId = 1,
                    SalesId = 1,
                },
                new Sales
                {
                    Quarter = 2,
                    Year = 2003,
                    Amount = 56234,
                    EmployeeId = 2,
                    SalesId = 2,
                },
                new Sales
                {
                    Quarter = 3,
                    Year = 2005,
                    Amount = 48631,
                    EmployeeId = 3,
                    SalesId = 3
                }
                );
        }
    }
}

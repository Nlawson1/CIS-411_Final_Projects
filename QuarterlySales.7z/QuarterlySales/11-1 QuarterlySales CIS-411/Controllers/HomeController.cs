﻿using System.Linq;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using _11_1_QuarterlySales_CIS_411.Models;

namespace _11_1_QuarterlySales_CIS_411.Controllers
{
    public class HomeController : Controller
    {
        private SalesContext context { get; set; }

        public HomeController(SalesContext ctx) => context = ctx;

        [HttpGet]

        public ViewResult Index(int id)
        {
            IQueryable<Sales> query = context.Sales
                .Include(s => s.Employee)
                .OrderBy(s => s.Year);
            if (id > 0)
                query = query.Where(s => s.EmployeeId == id);

            var vm = new SalesListViewModel
            {
                Sales = query.ToList(),
                Employees = context.Employees.OrderBy(e => e.Firstname).ToList(),
                EmployeeId = id
            };
            return View(vm);
        }

        [HttpPost]

        public RedirectToActionResult Index(Employee employee)
        {
            if (employee.EmployeeId > 0)
                return RedirectToAction("Index", new { id = employee.EmployeeId });
            else
                return RedirectToAction("Index", new { id = "" });
        }
    }
}
